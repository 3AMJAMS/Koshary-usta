/* @ds-bundle: {"format":4,"namespace":"KosharyUstaDesignSystem_f12ad9","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"KS_GLYPHS","sourcePath":"components/core/Icon.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Panel","sourcePath":"components/core/Panel.jsx"},{"name":"PanelHeading","sourcePath":"components/core/Panel.jsx"},{"name":"PanelRule","sourcePath":"components/core/Panel.jsx"},{"name":"ARCH","sourcePath":"components/game/CustomerFigure.jsx"},{"name":"ARCH_FROM","sourcePath":"components/game/CustomerFigure.jsx"},{"name":"CustomerFigure","sourcePath":"components/game/CustomerFigure.jsx"},{"name":"IngredientVat","sourcePath":"components/game/IngredientVat.jsx"},{"name":"KosharyBowl","sourcePath":"components/game/KosharyBowl.jsx"},{"name":"ING","sourcePath":"components/game/OrderTicket.jsx"},{"name":"OrderTicket","sourcePath":"components/game/OrderTicket.jsx"},{"name":"PrepCard","sourcePath":"components/game/PrepCard.jsx"},{"name":"ServeFeedback","sourcePath":"components/game/ServeFeedback.jsx"},{"name":"StatRows","sourcePath":"components/game/StatRows.jsx"},{"name":"StatRow","sourcePath":"components/game/StatRows.jsx"},{"name":"ComboMeter","sourcePath":"components/hud/ComboMeter.jsx"},{"name":"EventBanner","sourcePath":"components/hud/EventBanner.jsx"},{"name":"Meter","sourcePath":"components/hud/Meter.jsx"},{"name":"PatienceMeter","sourcePath":"components/hud/PatienceMeter.jsx"},{"name":"Shout","sourcePath":"components/hud/Shout.jsx"},{"name":"StatReadout","sourcePath":"components/hud/StatReadout.jsx"},{"name":"Toast","sourcePath":"components/hud/Toast.jsx"},{"name":"VENUES","sourcePath":"components/progression/ChapterCard.jsx"},{"name":"ChapterCard","sourcePath":"components/progression/ChapterCard.jsx"},{"name":"StarRating","sourcePath":"components/progression/StarRating.jsx"},{"name":"UpgradeCard","sourcePath":"components/progression/UpgradeCard.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"e4f99acbc286","components/core/Button.jsx":"927fe0078ced","components/core/Icon.jsx":"283c0fa545ba","components/core/IconButton.jsx":"ad9b63fb5535","components/core/Panel.jsx":"7aa93dea4e77","components/core/tweaks-panel.js":"d259e3a86f73","components/game/CustomerFigure.jsx":"d0b8b871a290","components/game/IngredientVat.jsx":"c842edf19dea","components/game/KosharyBowl.jsx":"e29e5d95f37d","components/game/OrderTicket.jsx":"10e47f09daf2","components/game/PrepCard.jsx":"ca08717952c9","components/game/ServeFeedback.jsx":"7020ddde55fc","components/game/StatRows.jsx":"f773dc9f3a38","components/hud/ComboMeter.jsx":"978f71733234","components/hud/EventBanner.jsx":"510d7def498e","components/hud/Meter.jsx":"aa7f25966624","components/hud/PatienceMeter.jsx":"6f041c3014c6","components/hud/Shout.jsx":"8a72003fdb91","components/hud/StatReadout.jsx":"0da541cc12ed","components/hud/Toast.jsx":"495c380c9bb5","components/progression/ChapterCard.jsx":"ed1816c6eed1","components/progression/StarRating.jsx":"3697f29dd07a","components/progression/UpgradeCard.jsx":"01a38f376bbf","ui_kits/game/LevelSelect.jsx":"a00ed7a5f277","ui_kits/game/ResultsScreen.jsx":"4d83921986f5","ui_kits/game/Scene.jsx":"57cd6c4e861a","ui_kits/game/ShiftScreen.jsx":"59cfe9a1f9d9","ui_kits/game/ShopScreen.jsx":"0cc946e8f3c7","ui_kits/game/TitleScreen.jsx":"9de67324aab6"},"inlinedExternals":[],"unexposedExports":[{"name":"moodOf","sourcePath":"components/game/CustomerFigure.jsx"},{"name":"nameOf","sourcePath":"components/game/OrderTicket.jsx"},{"name":"patienceColor","sourcePath":"components/hud/PatienceMeter.jsx"},{"name":"slangOf","sourcePath":"components/game/OrderTicket.jsx"}]} */

(() => {

const __ds_ns = (window.KosharyUstaDesignSystem_f12ad9 = window.KosharyUstaDesignSystem_f12ad9 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE = {
  neutral: {
    background: "var(--surface-tag)",
    color: "#F2DFC4"
  },
  ok: {
    background: "var(--surface-ok)",
    color: "var(--text-ok)"
  },
  no: {
    background: "var(--surface-no)",
    color: "var(--text-no)"
  }
};

/** An order component as a pill: what's in the bowl, what's right, what's wrong. */
function Badge({
  tone = "neutral",
  children,
  style,
  ...rest
}) {
  const face = TONE[tone] || TONE.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      fontSize: "var(--fs-tag)",
      fontWeight: "var(--fw-bold)",
      padding: "var(--pad-tag)",
      borderRadius: "var(--radius-pill)",
      border: "var(--outline-ink-thin)",
      whiteSpace: "nowrap",
      ...face,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FACE = {
  brass: {
    background: "var(--btn-brass)",
    color: "var(--text-on-brass)"
  },
  ghost: {
    background: "var(--btn-ghost)",
    color: "#FFEBCD"
  },
  hot: {
    background: "var(--btn-hot)",
    color: "#FFF3E6"
  },
  go: {
    background: "var(--btn-go)",
    color: "#0E2E19"
  }
};

/**
 * The dock button. Brass by default; ghost for secondary, hot to refuse a
 * customer, go to confirm. Presses down 4px and the ink slab collapses.
 */
function Button({
  variant = "brass",
  wide = false,
  block = false,
  pulse = false,
  disabled = false,
  sub,
  children,
  style,
  ...rest
}) {
  const face = FACE[variant] || FACE.brass;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "data-ks-press": "",
    disabled: disabled,
    style: {
      flex: block ? "1 1 100%" : wide ? 2 : 1,
      minHeight: "var(--size-btn)",
      borderRadius: "var(--radius-btn)",
      border: "var(--outline-ink)",
      fontFamily: "var(--font-ui)",
      fontWeight: "var(--fw-black)",
      fontSize: "var(--fs-btn)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: sub ? "column" : "row",
      gap: "var(--space-4)",
      padding: "0 var(--space-7)",
      boxShadow: "var(--shadow-btn)",
      opacity: disabled ? 0.42 : 1,
      animation: pulse ? "ks-btn-pulse var(--dur-btn-pulse) infinite" : undefined,
      ...face,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, children), sub ? /*#__PURE__*/React.createElement("small", {
    style: {
      display: "block",
      fontSize: "var(--fs-btn-sub)",
      fontWeight: "var(--fw-bold)",
      opacity: 0.8,
      marginTop: "-2px"
    }
  }, sub) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The game's actual glyph set. There is no icon font and no SVG set in the
 * source — archetypes are emoji, and the rest are typographic characters set
 * in Cairo. Keep this map as the single place they are named.
 */
const KS_GLYPHS = {
  // customer archetypes, exactly as ARCH.icon in the source
  walkin: "🙂",
  office: "⏱",
  regular: "★",
  tourist: "📷",
  family: "👨‍👩‍👧",
  critic: "📝",
  // counter + HUD
  star: "★",
  beat: "♪",
  shatta: "🌶",
  check: "✓"
};

/**
 * Renders one of the game's glyphs at a given size. Emoji are left in their
 * own colour; typographic glyphs take `color`.
 */
function Icon({
  name,
  glyph,
  size = "1em",
  color,
  label,
  style,
  ...rest
}) {
  const ch = glyph || KS_GLYPHS[name] || name;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: label ? "img" : "presentation",
    "aria-label": label,
    "aria-hidden": label ? undefined : "true",
    style: {
      fontSize: size,
      lineHeight: 1,
      display: "inline-block",
      fontFamily: "var(--font-ui)",
      color,
      ...style
    }
  }, rest), ch);
}
Object.assign(__ds_scope, { KS_GLYPHS, Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The small square chrome button on the HUD rail: sound, pause, language. */
function IconButton({
  label,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "data-ks-press": "icon",
    "aria-label": label,
    style: {
      width: "var(--size-iconbtn)",
      height: "var(--size-iconbtn)",
      borderRadius: "var(--radius-iconbtn)",
      border: "var(--outline-ink-thin)",
      background: "var(--surface-iconbtn)",
      color: "var(--text-on-ink)",
      fontSize: "var(--fs-iconbtn)",
      fontWeight: "var(--fw-bold)",
      fontFamily: "var(--font-ui)",
      display: "grid",
      placeItems: "center",
      padding: 0,
      boxShadow: "var(--shadow-iconbtn)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Panel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The overlay card every non-gameplay screen is built from: title, story
 * beats, shop, day-end. Dark wall gradient, thick ink outline, 7px ink slab.
 */
function Panel({
  eyebrow,
  title,
  children,
  style,
  bodyStyle,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      background: "var(--surface-card)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-card)",
      padding: "var(--pad-card)",
      boxShadow: "var(--shadow-card)",
      animation: "ks-card-in var(--dur-card-in) var(--ease-spring-card)",
      ...style
    }
  }, rest), eyebrow ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      fontSize: "var(--fs-eyebrow)",
      fontWeight: "var(--fw-black)",
      color: "var(--text-on-brass)",
      marginBottom: "var(--space-4)",
      letterSpacing: ".4px",
      background: "var(--brass)",
      border: "var(--outline-ink-thin)",
      borderRadius: "var(--radius-pill)",
      padding: "var(--pad-eyebrow)",
      boxShadow: "var(--shadow-eyebrow)"
    }
  }, eyebrow) : null, title ? /*#__PURE__*/React.createElement("h2", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-card-h2)",
      margin: "0 0 var(--space-2)",
      color: "var(--text-head)",
      lineHeight: "var(--lh-display)",
      textShadow: "var(--shadow-text-display)"
    }
  }, title) : null, /*#__PURE__*/React.createElement("div", {
    style: bodyStyle
  }, children));
}

/** Section heading inside a Panel. */
function PanelHeading({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("h3", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-card-h3)",
      margin: "var(--space-13) 0 var(--space-6)",
      color: "var(--brass-hi)",
      ...style
    }
  }, children);
}

/** The 2.5px brass-tinted divider used between Panel sections. */
function PanelRule({
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      height: "2.5px",
      borderRadius: "2px",
      background: "rgba(255,220,160,.25)",
      margin: "var(--space-11) 0",
      ...style
    }
  });
}
Object.assign(__ds_scope, { Panel, PanelHeading, PanelRule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Panel.jsx", error: String((e && e.message) || e) }); }

// components/core/tweaks-panel.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  // data-om-starter: inert presence marker — Claude Design's starter-usage
  // probe reads it. The closed panel renders nothing, so the marker rides
  // the <html> element as an attribute instead of a rendered node — zero
  // elements added, so page CSS (even structural selectors like
  // :nth-child) can never observe it. It records that the page WIRES a
  // tweaks panel, whether or not the panel is open. Keep this effect.
  React.useEffect(() => {
    document.documentElement.setAttribute('data-om-starter', 'tweaks-panel');
    return () => document.documentElement.removeAttribute('data-om-starter');
  }, []);
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/tweaks-panel.js", error: String((e && e.message) || e) }); }

// components/game/OrderTicket.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The seven things on the counter. `slang` is what the shop actually calls
 * each one — a regular orders in it, and from chapter 4 everyone does.
 * Colours are the exact col / col2 pair each ingredient is drawn with.
 */
const ING = {
  rzmix: {
    ar: "رز بعدس وشعرية",
    en: "Rice, lentil & vermicelli",
    slang: "بندق",
    slangEn: "bondo’",
    col: "var(--ing-rzmix)",
    col2: "var(--ing-rzmix-shade)",
    vessel: "vat",
    w: 1.00
  },
  ruz: {
    ar: "رز بشعرية",
    en: "Rice & vermicelli",
    slang: "بندق",
    slangEn: "bondo’",
    col: "var(--ing-ruz)",
    col2: "var(--ing-ruz-shade)",
    vessel: "vat",
    w: 1.00
  },
  maca: {
    ar: "مكرونة",
    en: "Macaroni",
    slang: "لوز",
    slangEn: "loz",
    col: "var(--ing-maca)",
    col2: "var(--ing-maca-shade)",
    vessel: "vat",
    w: 0.95
  },
  ads: {
    ar: "عدس",
    en: "Brown lentils",
    slang: "كهرمان",
    slangEn: "kahraman",
    col: "var(--ing-ads)",
    col2: "var(--ing-ads-shade)",
    vessel: "vat",
    w: 1.05
  },
  homos: {
    ar: "حمص",
    en: "Chickpeas",
    slang: "حمص",
    slangEn: "homos",
    col: "var(--ing-homos)",
    col2: "var(--ing-homos-shade)",
    vessel: "pot",
    w: 0.85
  },
  salsa: {
    ar: "صلصة",
    en: "Tomato sauce",
    slang: "مونة",
    slangEn: "moona",
    col: "var(--ing-salsa)",
    col2: "var(--ing-salsa-shade)",
    vessel: "sauce",
    w: 1.15
  },
  taqleya: {
    ar: "تقلية",
    en: "Crispy onions",
    slang: "ورد",
    slangEn: "ward",
    col: "var(--ing-taqleya)",
    col2: "var(--ing-taqleya-shade)",
    vessel: "tray",
    w: 1.45
  }
};

/** The counter's own word for a component, in whichever script is on screen. */
function slangOf(key, lang = "ar") {
  const i = ING[key];
  if (!i) return key;
  return lang === "ar" ? i.slang : i.slangEn || i.en;
}

/** The plain name, in whichever script is on screen. */
function nameOf(key, lang = "ar") {
  const i = ING[key];
  if (!i) return key;
  return lang === "ar" ? i.ar : i.en;
}

/**
 * The paid ticket on the spike. Paper slip, perforated bottom edge, flutters
 * down when it arrives and ticks when a line is filled.
 */
function OrderTicket({
  no,
  name,
  who,
  whoIcon,
  lines = [],
  total,
  tick = false,
  lang = "ar",
  slang = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      width: "min(52%, var(--slip-max))",
      background: "var(--surface-slip)",
      color: "var(--text-slip)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-slip)",
      padding: "var(--pad-slip)",
      fontSize: "var(--fs-slip)",
      lineHeight: "var(--lh-slip)",
      boxShadow: "var(--shadow-slip)",
      transformOrigin: "top center",
      animation: tick ? "ks-slip-tick var(--dur-slip-tick) ease-out" : "ks-slip-in var(--dur-slip-in) var(--ease-spring)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      borderBottom: "1.5px dashed rgba(42,31,23,.35)",
      paddingBottom: "var(--space-2)",
      marginBottom: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-slip-name)",
      lineHeight: "var(--lh-tight)",
      textShadow: "none"
    }
  }, name), no != null ? /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": "",
    style: {
      fontSize: "var(--fs-slip-no)",
      opacity: 0.65,
      fontWeight: "var(--fw-bold)"
    }
  }, "#", no) : null), who ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-slip-who)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-slip-extra)",
      letterSpacing: "var(--ls-chip)",
      margin: "-1px 0 var(--space-2)",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)"
    }
  }, whoIcon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, whoIcon) : null, who) : null, /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: "none"
    }
  }, lines.map((l, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-5)",
      fontWeight: "var(--fw-semibold)",
      color: l.state === "no" ? "var(--text-slip-no)" : l.state === "ex" ? "var(--text-slip-extra)" : undefined,
      textDecoration: l.state === "no" ? "line-through" : undefined,
      opacity: l.state === "no" ? 0.8 : 1
    }
  }, /*#__PURE__*/React.createElement("span", null, slang ? slangOf(l.key, lang) : nameOf(l.key, lang)), l.qty != null ? /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": ""
  }, "\xD7", l.qty) : null))), total != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-3)",
      paddingTop: "var(--space-2)",
      borderTop: "1.5px dashed rgba(42,31,23,.35)",
      display: "flex",
      justifyContent: "space-between",
      fontSize: "var(--fs-combo-label)",
      fontWeight: "var(--fw-bold)"
    }
  }, /*#__PURE__*/React.createElement("span", null, lang === "ar" ? "الحساب" : "Total"), /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": ""
  }, total)) : null, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetInline: 0,
      bottom: "-5px",
      height: "6px",
      background: "repeating-linear-gradient(90deg,#E4D5B4 0 5px,transparent 5px 10px)"
    }
  }));
}
Object.assign(__ds_scope, { ING, slangOf, nameOf, OrderTicket });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/OrderTicket.jsx", error: String((e && e.message) || e) }); }

// components/game/IngredientVat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Steel for the boiled things, a shallow tray for the onions. */
const VESSEL = {
  vat: {
    h: 78,
    lip: 12,
    radius: "var(--radius-up)"
  },
  pot: {
    h: 66,
    lip: 11,
    radius: "var(--radius-up)"
  },
  sauce: {
    h: 58,
    lip: 10,
    radius: "var(--radius-upico)"
  },
  tray: {
    h: 40,
    lip: 8,
    radius: "var(--radius-upico)"
  }
};

/**
 * A CSS STAND-IN for a canvas-drawn vessel. The shipping game paints every
 * vat, pot, sauce jug and onion tray on the canvas with an ink outline, a
 * steel rim highlight and per-grain fill. Use this in mockups and static
 * cards; read the canvas for the real thing.
 */
function IngredientVat({
  ingredient = "ruz",
  level = 100,
  steam = true,
  active = false,
  empty = false,
  count,
  label,
  lang = "ar",
  onScoop,
  style,
  ...rest
}) {
  const ing = __ds_scope.ING[ingredient] || __ds_scope.ING.ruz;
  const v = VESSEL[ing.vessel] || VESSEL.vat;
  const pct = Math.max(0, Math.min(100, level));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-3)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", _extends({}, onScoop ? {
    "data-ks-press": "prep",
    role: "button",
    tabIndex: 0,
    onClick: onScoop
  } : {}, {
    style: {
      position: "relative",
      width: "72px",
      height: v.h,
      borderRadius: v.radius,
      border: "var(--outline-ink)",
      background: "linear-gradient(180deg, var(--steel-hi) 0%, var(--steel) 22%, var(--steel-lo) 78%, var(--steel-dk) 100%)",
      boxShadow: active ? "var(--shadow-up), 0 0 0 3px var(--brass)" : "var(--shadow-up)",
      overflow: "hidden",
      animation: empty ? "ks-prep-warn var(--dur-prep-warn) infinite" : undefined
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetInline: "4px",
      bottom: "4px",
      height: "calc(" + pct + "% - 8px)",
      minHeight: pct > 0 ? "6px" : 0,
      borderRadius: "0 0 " + v.radius + " " + v.radius,
      background: "linear-gradient(180deg, " + ing.col + ", " + ing.col2 + ")",
      transition: "height var(--dur-meter) var(--ease-spring-meter)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0.5,
      mixBlendMode: "multiply",
      backgroundImage: "radial-gradient(" + ing.col2 + " 1px, transparent 1.4px)",
      backgroundSize: ing.vessel === "sauce" ? "10px 10px" : "6px 6px"
    }
  })), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetInline: 0,
      top: 0,
      height: v.lip,
      background: "linear-gradient(180deg, var(--steel-hi), var(--steel-lo))",
      borderBottom: "var(--outline-ink-thin)"
    }
  }), steam ? /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetInline: 0,
      top: "-18px",
      height: "24px",
      pointerEvents: "none"
    }
  }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      position: "absolute",
      insetInlineStart: 14 + i * 18 + "px",
      bottom: 0,
      width: "13px",
      height: "13px",
      borderRadius: "50%",
      background: "var(--daqqa)",
      filter: "blur(4px)",
      opacity: 0
    }
  }))) : null, count != null ? /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": "",
    style: {
      position: "absolute",
      insetInlineEnd: "4px",
      bottom: "4px",
      fontSize: "var(--fs-prep-qty)",
      fontWeight: "var(--fw-black)",
      color: "var(--ink)",
      background: "var(--brass-hi)",
      border: "var(--outline-ink-thin)",
      borderRadius: "var(--radius-pill)",
      padding: "0 5px"
    }
  }, count) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-prep-sub)",
      fontWeight: "var(--fw-bold)",
      color: empty ? "var(--text-no)" : "var(--text-head)",
      textAlign: "center",
      whiteSpace: "nowrap"
    }
  }, label || __ds_scope.nameOf(ingredient, lang)));
}
Object.assign(__ds_scope, { IngredientVat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/IngredientVat.jsx", error: String((e && e.message) || e) }); }

// components/game/KosharyBowl.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A CSS STAND-IN for the canvas-drawn bowl. The shipping game paints the bowl,
 * every layer and the overfill wobble on the canvas. Use this for static cards
 * and mockups; read the canvas for the real thing.
 *
 * Layers stack bottom-up in the order they were scooped, which is how the
 * player checks their own work against the slip.
 */
function KosharyBowl({
  size = 150,
  layers = [],
  steam = false,
  overfull = false,
  style,
  ...rest
}) {
  const total = layers.reduce((n, l) => n + (l.amount || 1), 0);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      width: size,
      ...style
    }
  }, rest), overfull ? /*#__PURE__*/React.createElement("span", {
    "data-ks-display": "",
    "data-ks-outline": "",
    style: {
      position: "absolute",
      insetBlockStart: "-26px",
      insetInline: 0,
      textAlign: "center",
      fontSize: "var(--fs-event-body)",
      color: "var(--bad)",
      WebkitTextStroke: "3px var(--ink)",
      paintOrder: "stroke fill",
      whiteSpace: "nowrap"
    }
  }, "OVERFULL!") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: size * 0.52,
      overflow: "hidden",
      borderRadius: "0 0 " + size * 0.44 + "px " + size * 0.44 + "px",
      border: "var(--outline-ink)",
      background: "linear-gradient(180deg, var(--steel-hi), var(--steel) 34%, var(--steel-lo) 86%, var(--steel-dk))",
      boxShadow: overfull ? "var(--shadow-up), 0 0 0 3px var(--bad)" : "var(--shadow-up)",
      display: "flex",
      flexDirection: "column-reverse"
    }
  }, layers.map((l, i) => {
    const ing = __ds_scope.ING[l.key];
    if (!ing) return null;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: "relative",
        flex: l.amount || 1,
        background: "linear-gradient(180deg, " + ing.col + ", " + ing.col2 + ")"
      }
    }, /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        position: "absolute",
        inset: 0,
        opacity: 0.45,
        mixBlendMode: "multiply",
        backgroundImage: "radial-gradient(" + ing.col2 + " 1px, transparent 1.4px)",
        backgroundSize: "6px 6px"
      }
    }));
  }), !total ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: "rgba(0,0,0,.35)"
    }
  }) : null), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      width: size * 0.36,
      height: size * 0.06,
      margin: "0 auto",
      background: "var(--steel-lo)",
      border: "var(--outline-ink-thin)",
      borderTop: 0,
      borderRadius: "0 0 " + size * 0.04 + "px " + size * 0.04 + "px"
    }
  }));
}
Object.assign(__ds_scope, { KosharyBowl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/KosharyBowl.jsx", error: String((e && e.message) || e) }); }

// components/game/ServeFeedback.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE = {
  good: "var(--text-pos)",
  perfect: "var(--brass-hi)",
  kemala: "var(--good)",
  combo: "var(--combo)",
  warn: "var(--warn)",
  spill: "var(--bad)"
};

/**
 * The floating judgement pop. Ink-stroked display type that punches up, holds
 * a beat, then drifts away. `big` for the ones that matter.
 */
function ServeFeedback({
  kind = "good",
  children,
  big = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-ks-display": "",
    "data-ks-outline": "",
    style: {
      fontFamily: "var(--font-display)",
      fontSize: big ? "var(--fs-pop-big)" : "var(--fs-pop)",
      color: TONE[kind] || "#fff",
      WebkitTextStroke: (big ? "var(--stroke-pop-big)" : "var(--stroke-pop)") + " var(--ink)",
      paintOrder: "stroke fill",
      textShadow: "0 3px 0 rgba(0,0,0,.35)",
      whiteSpace: "nowrap",
      pointerEvents: "none",
      animation: "ks-pop-up var(--dur-pop) var(--ease-pop-score) forwards",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { ServeFeedback });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/ServeFeedback.jsx", error: String((e && e.message) || e) }); }

// components/game/StatRows.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The ink-gapped stack of label/value rows on every overlay card. */
function StatRows({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--gap-rows)",
      background: "var(--ink)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-rows)",
      overflow: "hidden",
      margin: "var(--space-9) 0",
      boxShadow: "var(--shadow-rows)",
      ...style
    }
  }, rest), children);
}

/** One row. `total` for the bill line, `pos`/`neg` to colour the number. */
function StatRow({
  label,
  value,
  tone,
  total = false,
  onClick,
  style,
  ...rest
}) {
  const valueColor = total ? "var(--brass-hi)" : tone === "pos" ? "var(--text-pos)" : tone === "neg" ? "var(--text-neg)" : "var(--text-value)";
  return /*#__PURE__*/React.createElement("div", _extends({}, onClick ? {
    "data-ks-press": "row",
    role: "button",
    tabIndex: 0,
    onClick
  } : {}, {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: "var(--space-7)",
      background: total ? "var(--surface-row-total)" : "var(--surface-row)",
      padding: "var(--pad-row)",
      fontSize: "var(--fs-row)",
      fontWeight: "var(--fw-bold)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-label)"
    }
  }, label), /*#__PURE__*/React.createElement("b", {
    "data-ks-numeric": "",
    style: {
      fontWeight: "var(--fw-black)",
      color: valueColor,
      fontSize: total ? "var(--fs-chip-value)" : undefined
    }
  }, value));
}
Object.assign(__ds_scope, { StatRows, StatRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/StatRows.jsx", error: String((e && e.message) || e) }); }

// components/hud/ComboMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The koshary-symphony meter: scoop on the beat and the multiplier climbs.
 * Hot pink (--combo), used nowhere else in the game. Hidden at streak 0.
 */
function ComboMeter({
  streak = 0,
  multiplier = 1,
  progress = 0,
  label = "Rhythm",
  style,
  ...rest
}) {
  const on = streak > 0;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      transform: on ? "scale(1)" : "scale(.55)",
      transformOrigin: "top right",
      opacity: on ? 1 : 0,
      transition: "opacity var(--dur-patience), transform var(--dur-combo) var(--ease-spring-pop)",
      pointerEvents: "none",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--gap-combo)",
      background: "var(--surface-combo)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-pill)",
      padding: "var(--space-2) var(--space-11)",
      boxShadow: "var(--shadow-combo)"
    }
  }, /*#__PURE__*/React.createElement("b", {
    "data-ks-display": "",
    "data-ks-numeric": "",
    style: {
      fontSize: "var(--fs-combo)",
      lineHeight: "var(--lh-tight)",
      color: "var(--combo)",
      textShadow: "var(--shadow-text-sm)"
    }
  }, "\xD7", multiplier), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-combo-label)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-combo)",
      letterSpacing: "var(--ls-combo)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "var(--w-combo-bar)",
      height: "var(--h-combo-bar)",
      borderRadius: "var(--radius-bar)",
      background: "rgba(0,0,0,.55)",
      overflow: "hidden",
      boxShadow: "var(--ring-bar)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      display: "block",
      height: "100%",
      width: Math.max(0, Math.min(100, progress)) + "%",
      background: "var(--combo)",
      transition: "width var(--dur-bar) linear"
    }
  }))));
}
Object.assign(__ds_scope, { ComboMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/ComboMeter.jsx", error: String((e && e.message) || e) }); }

// components/hud/EventBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The morning headline — one daily modifier, shown centred over the stage
 * before service starts. Paper card on ink, springs in from 70%.
 */
function EventBanner({
  kicker,
  title,
  detail,
  open = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: "min(86%, var(--event-max))",
      background: "var(--paper)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-event)",
      padding: "var(--pad-event)",
      textAlign: "center",
      color: "var(--ink)",
      boxShadow: "var(--shadow-event)",
      opacity: open ? 1 : 0,
      transform: open ? "scale(1)" : "scale(.7)",
      transition: "opacity var(--dur-fade), transform var(--dur-event) var(--ease-spring)",
      ...style
    }
  }, rest), kicker ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-event-kicker)",
      fontWeight: "var(--fw-black)",
      letterSpacing: "var(--ls-kicker)",
      color: "#A2620C"
    }
  }, kicker) : null, title ? /*#__PURE__*/React.createElement("div", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-event)",
      lineHeight: "var(--lh-display)",
      margin: "var(--space-1) 0 var(--space-2)"
    }
  }, title) : null, detail ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-event-body)",
      fontWeight: "var(--fw-bold)",
      lineHeight: "var(--lh-body)",
      opacity: 0.85
    }
  }, detail) : null);
}
Object.assign(__ds_scope, { EventBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/EventBanner.jsx", error: String((e && e.message) || e) }); }

// components/hud/Meter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The generic bar used on overlay cards for reputation, batch quality and
 * batch quantity. Springs to its new width rather than sliding linearly —
 * unlike PatienceMeter, which is a timer.
 */
function Meter({
  value = 0,
  color = "var(--good)",
  style,
  barStyle,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": Math.round(pct),
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      height: "var(--h-meter)",
      borderRadius: "var(--radius-pill)",
      background: "var(--surface-well)",
      overflow: "hidden",
      border: "var(--outline-ink-thin)",
      flex: 1,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    style: {
      display: "block",
      height: "100%",
      width: pct + "%",
      borderRadius: "var(--radius-pill)",
      background: color,
      transition: "width var(--dur-meter) var(--ease-spring-meter)",
      ...barStyle
    }
  }));
}
Object.assign(__ds_scope, { Meter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/Meter.jsx", error: String((e && e.message) || e) }); }

// components/game/PrepCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * One batch on the morning prep board: how much is cooked and how good it is.
 * Turns green when it is ready and pulses red when the vat has run dry.
 */
function PrepCard({
  title,
  sub,
  swatch,
  quality = 0,
  quantity = 0,
  servings,
  state = "idle",
  onClick,
  style,
  ...rest
}) {
  const bg = state === "done" ? "var(--surface-prep-done)" : state === "empty" ? "var(--surface-prep-empty)" : "var(--surface-row)";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "data-ks-press": "prep",
    onClick: onClick,
    style: {
      position: "relative",
      overflow: "hidden",
      textAlign: "start",
      background: bg,
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-prep)",
      padding: "var(--pad-prep)",
      boxShadow: "var(--shadow-up)",
      fontFamily: "var(--font-ui)",
      color: "var(--text-body)",
      animation: state === "empty" ? "ks-prep-warn var(--dur-prep-warn) infinite" : undefined,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-prep-title)",
      color: "var(--text-head)",
      lineHeight: "var(--lh-snug)"
    }
  }, title), sub ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-prep-sub)",
      color: "#C6B098",
      margin: "var(--space-2) 0 var(--space-5)",
      fontWeight: "var(--fw-bold)"
    }
  }, sub) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Meter, {
    value: quantity,
    color: "var(--brass)"
  }), /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": "",
    style: {
      fontSize: "var(--fs-prep-qty)",
      fontWeight: "var(--fw-bold)",
      minWidth: "30px",
      textAlign: "end"
    }
  }, servings != null ? servings : Math.round(quantity) + "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      alignItems: "center",
      marginTop: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Meter, {
    value: quality,
    color: "var(--good)"
  }), /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": "",
    style: {
      fontSize: "var(--fs-prep-qty)",
      fontWeight: "var(--fw-bold)",
      minWidth: "30px",
      textAlign: "end"
    }
  }, Math.round(quality), "%")), swatch ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: "var(--space-7)",
      insetInlineEnd: "var(--space-7)",
      width: "15px",
      height: "15px",
      borderRadius: "50%",
      background: swatch,
      border: "1.5px solid rgba(255,255,255,.25)"
    }
  }) : null);
}
Object.assign(__ds_scope, { PrepCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/PrepCard.jsx", error: String((e && e.message) || e) }); }

// components/hud/PatienceMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Thresholds are fixed game-wide: above 60 good, 60-30 warn, below 30 bad. */
function patienceColor(pct) {
  return pct > 60 ? "var(--good)" : pct > 30 ? "var(--warn)" : "var(--bad)";
}

/**
 * The current customer's patience, pinned top-inline-end of the stage.
 * Drains linearly — easing a timer reads as lag. Panics below 22%.
 */
function PatienceMeter({
  value = 100,
  panic,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  const isPanic = panic == null ? pct <= 22 : panic;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": Math.round(pct),
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      width: "var(--w-patience)",
      height: "var(--h-patience)",
      background: "var(--surface-well)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-pill)",
      overflow: "hidden",
      boxShadow: "var(--shadow-pat)",
      animation: isPanic ? "ks-patience-panic var(--dur-panic) infinite" : undefined,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    style: {
      display: "block",
      height: "100%",
      width: pct + "%",
      background: patienceColor(pct),
      transition: "width var(--dur-patience) linear, background var(--dur-meter)"
    }
  }));
}
Object.assign(__ds_scope, { patienceColor, PatienceMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/PatienceMeter.jsx", error: String((e && e.message) || e) }); }

// components/game/CustomerFigure.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Who walks in. Every multiplier here is from the source — an office worker
 * runs out of patience fastest (0.62), a tourist tips best (2.10), and a
 * critic moves reputation more than three times as hard as anyone else.
 */
const ARCH = {
  walkin: {
    ar: "زبون",
    en: "Walk-in",
    pat: 1.00,
    tip: 1.00,
    rep: 1.00,
    w: 26,
    icon: "🙂"
  },
  office: {
    ar: "موظف",
    en: "Office worker",
    pat: 0.62,
    tip: 0.85,
    rep: 0.90,
    w: 22,
    icon: "⏱",
    arS: "مستعجل — الغدا نص ساعة",
    enS: "In a hurry — half an hour for lunch"
  },
  regular: {
    ar: "زبون قديم",
    en: "Regular",
    pat: 1.30,
    tip: 1.35,
    rep: 1.45,
    w: 18,
    icon: "★",
    slangAlways: true,
    arS: "بيطلب بلغة المحل",
    enS: "Orders in the house language"
  },
  tourist: {
    ar: "سايح",
    en: "Tourist",
    pat: 1.45,
    tip: 2.10,
    rep: 0.75,
    w: 12,
    icon: "📷",
    showman: true,
    arS: "عايز يتفرج على الشغل",
    enS: "Wants to watch the show"
  },
  family: {
    ar: "عيلة",
    en: "Family",
    pat: 1.20,
    tip: 1.25,
    rep: 1.20,
    w: 10,
    icon: "👨‍👩‍👧",
    bigOnly: true,
    arS: "حلّة للبيت",
    enS: "A pot to take home"
  },
  critic: {
    ar: "صحفي",
    en: "Critic",
    pat: 0.90,
    tip: 1.60,
    rep: 3.20,
    w: 5,
    icon: "📝",
    strict: true,
    arS: "بيكتب في الجرنان",
    enS: "Writes for the paper"
  }
};

/** Which chapter each archetype starts appearing in. */
const ARCH_FROM = {
  walkin: 0,
  office: 1,
  regular: 1,
  tourist: 3,
  family: 3,
  critic: 2
};

/** Mood follows the same thresholds as the patience bar. */
function moodOf(patience) {
  return patience > 80 ? "delighted" : patience > 60 ? "happy" : patience > 30 ? "impatient" : "annoyed";
}

/**
 * A STAND-IN. In the shipping game the customer is drawn on the canvas by
 * makeLook() — randomised skin, cloth, hat, hijab, beard, glasses, plus a
 * tourist camera flash — and there is no DOM customer card at all. This
 * component exists so mockups can place a figure with the correct archetype
 * data, label and mood ring. Pass `art` once real artwork exists.
 */
function CustomerFigure({
  archetype = "walkin",
  patience = 100,
  lang = "ar",
  art,
  size = 96,
  showLabel = true,
  style,
  ...rest
}) {
  const a = ARCH[archetype] || ARCH.walkin;
  const ring = __ds_scope.patienceColor(patience);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-4)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: "var(--radius-up)",
      border: "var(--outline-ink)",
      boxShadow: "inset 0 0 0 3px " + ring + ", var(--shadow-up)",
      background: art ? undefined : "var(--surface-upico)",
      display: "grid",
      placeItems: "center",
      overflow: "hidden",
      fontSize: Math.round(size * 0.42)
    }
  }, art || /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, a.icon)), showLabel ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-prep-title)",
      color: "var(--text-head)",
      lineHeight: "var(--lh-tight)"
    }
  }, lang === "ar" ? a.ar : a.en), (lang === "ar" ? a.arS : a.enS) ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-slip-who)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-muted)",
      textAlign: "center",
      maxWidth: size + 40
    }
  }, lang === "ar" ? a.arS : a.enS) : null) : null);
}
Object.assign(__ds_scope, { ARCH, ARCH_FROM, moodOf, CustomerFigure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/CustomerFigure.jsx", error: String((e && e.message) || e) }); }

// components/hud/Shout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A comic speech balloon from the shop — the customer calling an order in
 * the house language, or the runner shouting it down to the kitchen.
 */
function Shout({
  open = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      maxWidth: "42%",
      background: "var(--paper)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-shout)",
      padding: "var(--pad-shout)",
      fontSize: "var(--fs-shout)",
      fontWeight: "var(--fw-bold)",
      color: "var(--ink)",
      textAlign: "center",
      boxShadow: "var(--shadow-shout)",
      opacity: open ? 1 : 0,
      transform: open ? "none" : "scale(.5) translateY(8px)",
      transformOrigin: "bottom right",
      transition: "opacity var(--dur-patience), transform var(--dur-balloon) var(--ease-spring-pop)",
      ...style
    }
  }, rest), children, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      bottom: "-13px",
      insetInlineEnd: "18px",
      width: 0,
      height: 0,
      border: "7px solid transparent",
      borderTopColor: "var(--ink)",
      borderBottom: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      bottom: "-8px",
      insetInlineEnd: "21px",
      zIndex: 1,
      width: 0,
      height: 0,
      border: "5px solid transparent",
      borderTopColor: "var(--paper)",
      borderBottom: 0
    }
  }));
}
Object.assign(__ds_scope, { Shout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/Shout.jsx", error: String((e && e.message) || e) }); }

// components/hud/StatReadout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VALUE_COLOR = {
  money: "var(--brass-hi)",
  rep: "var(--ward-hi)"
};

/**
 * A HUD chip on the steel rail: cash, reputation, day. `bump` fires the
 * punch-and-tilt when the number changes.
 */
function StatReadout({
  kind = "money",
  label,
  value,
  bump = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--gap-chip)",
      background: "var(--surface-chip)",
      border: "var(--outline-ink-thin)",
      borderRadius: "var(--radius-pill)",
      padding: "var(--pad-chip)",
      fontSize: "var(--fs-chip)",
      fontWeight: "var(--fw-bold)",
      letterSpacing: "var(--ls-chip)",
      whiteSpace: "nowrap",
      boxShadow: "var(--shadow-chip)",
      animation: bump ? "ks-chip-bump var(--dur-chip-bump) var(--ease-spring)" : undefined,
      ...style
    }
  }, rest), label ? /*#__PURE__*/React.createElement("span", null, label) : null, /*#__PURE__*/React.createElement("b", {
    "data-ks-numeric": "",
    style: {
      fontWeight: "var(--fw-black)",
      fontSize: "var(--fs-chip-value)",
      color: VALUE_COLOR[kind]
    }
  }, value));
}
Object.assign(__ds_scope, { StatReadout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/StatReadout.jsx", error: String((e && e.message) || e) }); }

// components/hud/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The one-line paper confirmation that slides up over the dock. */
function Toast({
  open = false,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      background: "var(--paper)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-pill)",
      padding: "var(--pad-toast)",
      fontSize: "var(--fs-toast)",
      fontWeight: "var(--fw-black)",
      color: "var(--ink)",
      textAlign: "center",
      maxWidth: "86vw",
      boxShadow: "var(--shadow-toast)",
      opacity: open ? 1 : 0,
      transform: open ? "translateY(-6px) scale(1)" : "scale(.8)",
      transition: "opacity var(--dur-fade), transform var(--dur-balloon) var(--ease-spring-pop)",
      pointerEvents: "none",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/Toast.jsx", error: String((e && e.message) || e) }); }

// components/progression/ChapterCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The three venues the story moves through. */
const VENUES = {
  cart: {
    ar: "عربية",
    en: "A cart"
  },
  shop: {
    ar: "محل",
    en: "A shop"
  },
  neon: {
    ar: "نيون",
    en: "Neon"
  }
};

/**
 * One chapter in the story — a year, a venue, and the days inside it. The game
 * is linear, so this reports progress rather than offering a choice.
 */
function ChapterCard({
  year,
  title,
  venue = "shop",
  days,
  dayReached,
  goal,
  state = "open",
  onClick,
  style,
  ...rest
}) {
  const locked = state === "locked";
  const done = state === "done";
  return /*#__PURE__*/React.createElement("div", _extends({}, onClick && !locked ? {
    "data-ks-press": "row",
    role: "button",
    tabIndex: 0,
    onClick
  } : {}, locked ? {
    "data-ks-state": "locked"
  } : {}, {
    style: {
      display: "flex",
      gap: "var(--gap-up)",
      alignItems: "center",
      background: done ? "var(--surface-prep-done)" : "var(--surface-row)",
      border: "var(--outline-ink)",
      borderRadius: "var(--radius-up)",
      padding: "var(--pad-up)",
      marginBottom: "var(--space-8)",
      boxShadow: "var(--shadow-up)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    "data-ks-display": "",
    style: {
      flex: "0 0 auto",
      minWidth: "var(--size-upico)",
      height: "var(--size-upico)",
      borderRadius: "var(--radius-upico)",
      display: "grid",
      placeItems: "center",
      background: "var(--surface-upico)",
      border: "var(--outline-ink)",
      padding: "0 var(--space-5)",
      fontSize: "var(--fs-up-title)",
      color: "var(--brass-hi)"
    }
  }, year), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-up-title)",
      color: "var(--text-head)",
      lineHeight: "var(--lh-snug)"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-up-desc)",
      color: "var(--text-muted)",
      lineHeight: "var(--lh-slip)",
      marginTop: "var(--space-1)",
      display: "flex",
      gap: "var(--space-5)",
      flexWrap: "wrap"
    }
  }, days != null ? /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": ""
  }, dayReached != null ? dayReached + " / " + days : days) : null, goal != null ? /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": ""
  }, goal) : null)));
}
Object.assign(__ds_scope, { VENUES, ChapterCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progression/ChapterCard.jsx", error: String((e && e.message) || e) }); }

// components/progression/StarRating.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The day's rating, 0-3. Stars are typographic ★ set large, ink-stroked when
 * lit, and they pop in sequence 160ms apart. Unlit stars stay visible at 78%
 * so the player can see what they missed.
 */
function StarRating({
  value = 0,
  max = 3,
  size = "var(--fs-star)",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "img",
    "aria-label": value + " / " + max,
    style: {
      display: "flex",
      gap: "var(--gap-stars)",
      justifyContent: "center",
      ...style
    }
  }, rest), Array.from({
    length: max
  }, (_, i) => {
    const lit = i < value;
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      "aria-hidden": "true",
      style: {
        fontSize: size,
        lineHeight: 1,
        color: lit ? "var(--brass-hi)" : "var(--text-star-empty)",
        transform: lit ? "scale(1)" : "scale(.78)",
        WebkitTextStroke: lit ? "var(--stroke-star) var(--ink)" : undefined,
        paintOrder: "stroke fill",
        textShadow: lit ? "var(--glow-star)" : undefined,
        animation: lit ? "ks-star-pop var(--dur-star) var(--ease-spring-star) both" : undefined,
        animationDelay: lit ? i * 0.16 + "s" : undefined
      }
    }, "\u2605");
  }));
}
Object.assign(__ds_scope, { StarRating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progression/StarRating.jsx", error: String((e && e.message) || e) }); }

// components/progression/UpgradeCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A row in the kit-and-fittings shop. Icon tile, name, one sentence of real
 * consequence, and a price button. Owned rows dim; locked rows desaturate.
 */
function UpgradeCard({
  icon,
  title,
  description,
  price,
  state = "buy",
  buyLabel,
  ownedLabel,
  cantLabel,
  onBuy,
  style,
  ...rest
}) {
  const owned = state === "owned";
  const locked = state === "locked";
  const cant = state === "cant";
  return /*#__PURE__*/React.createElement("div", _extends({}, owned ? {
    "data-ks-state": "owned"
  } : locked ? {
    "data-ks-state": "locked"
  } : {}, {
    style: {
      display: "flex",
      gap: "var(--gap-up)",
      alignItems: "flex-start",
      background: "var(--surface-row)",
      borderRadius: "var(--radius-up)",
      padding: "var(--pad-up)",
      marginBottom: "var(--space-8)",
      border: "var(--outline-ink)",
      boxShadow: "var(--shadow-up)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "0 0 var(--size-upico)",
      height: "var(--size-upico)",
      borderRadius: "var(--radius-upico)",
      display: "grid",
      placeItems: "center",
      background: "var(--surface-upico)",
      border: "var(--outline-ink)",
      fontSize: "22px"
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-ks-display": "",
    style: {
      fontSize: "var(--fs-up-title)",
      color: "var(--text-head)",
      lineHeight: "var(--lh-snug)"
    }
  }, title), description ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-up-desc)",
      color: "var(--text-muted)",
      lineHeight: "var(--lh-slip)",
      marginTop: "var(--space-1)"
    }
  }, description) : null), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "data-ks-press": "upbuy",
    disabled: owned || locked || cant,
    onClick: onBuy,
    style: {
      flex: "0 0 auto",
      alignSelf: "center",
      minWidth: "var(--size-upbuy-w)",
      minHeight: "var(--size-upbuy-h)",
      borderRadius: "var(--radius-upbuy)",
      border: "var(--outline-ink)",
      fontFamily: "var(--font-ui)",
      fontWeight: "var(--fw-black)",
      fontSize: "var(--fs-upbuy)",
      background: owned ? "var(--surface-ok)" : locked || cant ? "var(--surface-disabled)" : "linear-gradient(180deg, var(--brass-hi), var(--brass))",
      color: owned ? "var(--text-ok)" : locked || cant ? "var(--text-disabled)" : "var(--text-on-brass)",
      boxShadow: "var(--shadow-upbuy)"
    }
  }, owned ? ownedLabel || "Owned" : cant ? cantLabel || "Short" : /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": ""
  }, price != null ? price : buyLabel || "Buy")));
}
Object.assign(__ds_scope, { UpgradeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/progression/UpgradeCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/LevelSelect.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge,
  Panel,
  LevelNode,
  EventBanner,
  StatReadout
} = window.KosharyUstaDesignSystem_f12ad9;
const LEVELS = [{
  n: 1,
  en: "First morning",
  ar: "أول صباح",
  state: "cleared",
  stars: 3
}, {
  n: 2,
  en: "Market day",
  ar: "يوم السوق",
  state: "cleared",
  stars: 2
}, {
  n: 3,
  en: "Quiet morning",
  ar: "صباح هادي",
  state: "cleared",
  stars: 3
}, {
  n: 4,
  en: "Lunch rush",
  ar: "زحمة الضهر",
  state: "available",
  stars: 0,
  event: true
}, {
  n: 5,
  en: "Tour bus",
  ar: "أتوبيس سياحة",
  state: "locked",
  stars: 0
}, {
  n: 6,
  en: "The critic",
  ar: "الناقد",
  state: "locked",
  stars: 0
}];
const LS = {
  en: {
    chapter: "Chapter 2",
    place: "Sayeda Zeinab",
    back: "Back",
    start: "Start Shift",
    event: "Friday rush",
    detail: "The queue fills twice as fast. Keep the rice vat topped up.",
    mod: "−20% patience",
    money: "Pounds",
    rep: "Rep"
  },
  ar: {
    chapter: "الفصل الثاني",
    place: "السيدة زينب",
    back: "رجوع",
    start: "ابدأ الورديّة",
    event: "زحمة الجمعة",
    detail: "الطابور بيمتلي بسرعة الضعف. خلي حلة الرز مليانة.",
    mod: "−٢٠٪ صبر",
    money: "جنيه",
    rep: "السمعة"
  }
};
function LevelSelect({
  lang,
  setLang,
  onBack,
  onStart
}) {
  const t = LS[lang];
  const rtl = lang === "ar";
  const [sel, setSel] = React.useState(4);
  return /*#__PURE__*/React.createElement("div", {
    dir: rtl ? "rtl" : "ltr",
    style: {
      position: "absolute",
      inset: 0,
      background: "linear-gradient(180deg,#6b4324,#3a2317)"
    }
  }, /*#__PURE__*/React.createElement(StreetBackdrop, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      padding: "var(--space-7) var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    size: "sm",
    onClick: onBack,
    icon: /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-arrow-left",
      "data-ks-flip": true
    })
  }, t.back), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `400 ${rtl ? 34 : 32}px/1.1 var(--font-display)`,
      color: "var(--cream-50)"
    }
  }, t.chapter), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-semibold) var(--fs-caption)/1 var(--font-ui)`,
      color: "var(--cream-300)",
      letterSpacing: "var(--ls-wide)"
    }
  }, t.place)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginInlineStart: "auto",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.money
    }),
    label: t.money,
    value: "1,240"
  }), /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.reputation
    }),
    label: t.rep,
    value: "4.6",
    tone: "herb"
  }), /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    onChange: setLang
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: "relative",
      padding: "0 var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: "100%",
      borderRadius: "var(--radius-panel)",
      background: "linear-gradient(180deg, var(--cream-100), var(--cream-300))",
      border: "3px solid var(--cream-500)",
      boxShadow: "var(--shadow-rim), var(--shadow-3)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(60% 70% at 50% 40%, transparent 55%, rgba(120,79,45,.16))"
    }
  }), /*#__PURE__*/React.createElement("svg", {
    "aria-hidden": "true",
    viewBox: "0 0 1120 260",
    preserveAspectRatio: "none",
    style: {
      position: "absolute",
      insetBlockStart: "54px",
      insetInline: "24px",
      height: "260px",
      width: "calc(100% - 48px)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M60 180 C 200 60, 300 220, 430 130 S 660 40, 790 150 S 980 210, 1060 110",
    fill: "none",
    stroke: "rgba(120,79,45,.34)",
    strokeWidth: "5",
    strokeDasharray: "14 12",
    strokeLinecap: "round"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      padding: "var(--space-7) var(--space-6) 0"
    }
  }, LEVELS.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: l.n,
    style: {
      transform: `translateY(${[54, 0, 96, 24, 74, 10][i]}px)`
    }
  }, /*#__PURE__*/React.createElement(LevelNode, {
    number: rtl ? ["١", "٢", "٣", "٤", "٥", "٦"][i] : l.n,
    title: lang === "ar" ? l.ar : l.en,
    titleAr: lang === "ar" ? null : l.ar,
    state: l.state,
    stars: l.stars,
    event: l.event ? /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-megaphone"
    }) : null,
    onClick: () => l.state !== "locked" && setSel(l.n),
    style: sel === l.n && l.state !== "locked" ? {
      filter: "drop-shadow(0 0 16px rgba(227,176,75,.75))"
    } : null
  })))))), /*#__PURE__*/React.createElement("footer", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-7)",
      padding: "var(--space-7) var(--space-9) var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement(EventBanner, {
    tone: "hazard",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.event
    }),
    title: t.event,
    detail: t.detail,
    modifier: t.mod,
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "brass",
    size: "lg",
    onClick: onStart,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.bowl,
      size: "md"
    }),
    style: {
      whiteSpace: "nowrap"
    }
  }, t.start))));
}
Object.assign(window, {
  LevelSelect
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/LevelSelect.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/ResultsScreen.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge,
  Panel,
  StarRating,
  StatReadout,
  KosharyBowl
} = window.KosharyUstaDesignSystem_f12ad9;
const R = {
  en: {
    title: "Shift Over",
    sub: "Day 7 · Lunch rush",
    served: "Served",
    perfect: "Perfect bowls",
    kemala: "Kemala",
    spilled: "Spilled",
    best: "Best streak",
    takings: "Takings",
    tips: "Tips",
    total: "Total",
    retry: "Play Again",
    shop: "Shop",
    next: "Next Day",
    note: "Three regulars came back today. Keep the rice vat full and they will bring friends."
  },
  ar: {
    title: "خلصت الورديّة",
    sub: "اليوم ٧ · زحمة الضهر",
    served: "اتقدّم",
    perfect: "أطباق مظبوطة",
    kemala: "كمالة",
    spilled: "اتكب",
    best: "أطول سلسلة",
    takings: "المبيعات",
    tips: "بقشيش",
    total: "الإجمالي",
    retry: "العب تاني",
    shop: "المحل",
    next: "اليوم اللي بعده",
    note: "تلات زباين دايمين رجعوا النهاردة. خلي حلة الرز مليانة وهيجيبوا صحابهم."
  }
};
const ROWS = [["served", "ticket", "18", null], ["perfect", "perfect", "13", "herb"], ["kemala", "kemala", "6", "brass"], ["spilled", "spill", "2", "fail"], ["best", "combo", "×9", "brass"]];
function ResultsScreen({
  lang,
  setLang,
  onRetry,
  onShop,
  onNext
}) {
  const t = R[lang];
  const rtl = lang === "ar";
  return /*#__PURE__*/React.createElement("div", {
    dir: rtl ? "rtl" : "ltr",
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(StreetBackdrop, null), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--surface-overlay)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetBlockStart: "var(--space-7)",
      insetInlineEnd: "var(--space-8)",
      zIndex: 4
    }
  }, /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    onChange: setLang
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "grid",
      placeItems: "center",
      zIndex: 3
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    tone: "cream",
    elevation: 3,
    style: {
      width: "760px"
    },
    bodyStyle: {
      padding: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 ${rtl ? 46 : 42}px/1.05 var(--font-display)`,
      color: "var(--text-strong)"
    }
  }, t.title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--fw-semibold) var(--fs-caption)/1 var(--font-ui)",
      color: "var(--text-muted)",
      letterSpacing: "var(--ls-wide)",
      marginBlockStart: "6px"
    }
  }, t.sub), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBlockStart: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(StarRating, {
    value: 2,
    showEmpty: true,
    size: 40
  }))), /*#__PURE__*/React.createElement(KosharyBowl, {
    size: 150,
    steam: true,
    layers: [{
      key: "rice",
      amount: 2
    }, {
      key: "lentils"
    }, {
      key: "pasta"
    }, {
      key: "chickpeas"
    }, {
      key: "sauce"
    }, {
      key: "onion"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(5, 1fr)",
      gap: "var(--space-4)",
      marginBlockStart: "var(--space-7)"
    }
  }, ROWS.map(([k, icon, val, tone]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-3)",
      padding: "var(--space-5) var(--space-3)",
      borderRadius: "var(--radius-card)",
      background: "var(--cream-100)",
      border: "2px solid var(--line-rim)",
      boxShadow: "var(--shadow-sunken)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: KS_ICONS[icon],
    size: "lg",
    color: tone ? `var(--state-${tone === "herb" ? "good" : tone === "brass" ? "perfect" : "fail"})` : "var(--char-500)"
  }), /*#__PURE__*/React.createElement("span", {
    "data-ks-numeric": true,
    style: {
      font: "var(--fw-black) var(--fs-title-sm)/1 var(--font-ui)",
      color: "var(--text-strong)"
    }
  }, val), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-semibold) var(--fs-micro)/1.2 var(--font-ui)",
      color: "var(--text-muted)",
      textAlign: "center"
    }
  }, t[k])))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      marginBlockStart: "var(--space-6)",
      padding: "var(--space-5) var(--space-6)",
      borderRadius: "var(--radius-card)",
      background: "linear-gradient(180deg, var(--herb-500), var(--herb-700))",
      border: "2px solid var(--herb-700)",
      boxShadow: "var(--shadow-1)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-semibold) var(--fs-body)/1.5 var(--font-ui)",
      color: "var(--cream-100)",
      flex: 1
    }
  }, t.note), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)"
    }
  }, [[t.takings, "612"], [t.tips, "148"], [t.total, "760"]].map(([l, v], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--fw-semibold) var(--fs-micro)/1 var(--font-ui)",
      color: "rgba(251,240,220,.75)",
      letterSpacing: "var(--ls-wide)",
      textTransform: "uppercase"
    }
  }, l), /*#__PURE__*/React.createElement("div", {
    "data-ks-numeric": true,
    style: {
      font: `var(--fw-black) ${i === 2 ? "var(--fs-title-sm)" : "var(--fs-body-lg)"}/1.2 var(--font-ui)`,
      color: i === 2 ? "var(--brass-300)" : "var(--cream-50)"
    }
  }, v))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)",
      marginBlockStart: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    onClick: onRetry,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.back,
      size: "sm"
    })
  }, t.retry), /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    onClick: onShop,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.shop,
      size: "sm"
    })
  }, t.shop), /*#__PURE__*/React.createElement(Button, {
    variant: "brass",
    size: "lg",
    block: true,
    onClick: onNext,
    iconEnd: /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-arrow-right",
      "data-ks-flip": true
    })
  }, t.next)))));
}
Object.assign(window, {
  ResultsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/ResultsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/Scene.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge
} = window.KosharyUstaDesignSystem_f12ad9;
const STREET = {
  position: "absolute",
  inset: 0,
  background: "radial-gradient(120% 90% at 50% 12%, #7a4a28 0%, #4b2e1c 46%, var(--surface-street) 100%)"
};

/** Out-of-focus Cairo shopfront behind everything. Blurred so UI stays legible. */
function StreetBackdrop({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: STREET
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      filter: "blur(9px)",
      opacity: 0.85
    }
  }, [0, 1, 2, 3, 4, 5].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: "absolute",
      insetBlockEnd: `${120 + i % 3 * 46}px`,
      insetInlineStart: `${60 + i * 205}px`,
      width: "150px",
      height: `${210 + i % 2 * 90}px`,
      borderRadius: "10px 10px 0 0",
      background: i % 2 ? "linear-gradient(180deg,#6a4126,#3a2317)" : "linear-gradient(180deg,#7d5130,#412818)"
    }
  })), [0, 1, 2, 3, 4, 5, 6, 7].map(i => /*#__PURE__*/React.createElement("div", {
    key: `l${i}`,
    style: {
      position: "absolute",
      insetBlockStart: `${90 + i % 4 * 58}px`,
      insetInlineStart: `${100 + i * 152}px`,
      width: "26px",
      height: "26px",
      borderRadius: "50%",
      background: i % 3 ? "rgba(227,176,75,.75)" : "rgba(226,132,44,.6)",
      filter: "blur(3px)"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(70% 55% at 50% 78%, rgba(227,176,75,.22), transparent 70%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      boxShadow: "inset 0 0 180px 60px rgba(20,11,7,.7)"
    }
  }), children);
}

/** Hanging rice/pasta sacks and a strung bulb line — the shopfront dressing. */
function ShopDressing() {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetBlockStart: 0,
      insetInline: 0,
      height: "136px",
      pointerEvents: "none"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetBlockStart: "26px",
      insetInline: "-10px",
      height: "3px",
      background: "rgba(36,22,17,.55)",
      borderRadius: "2px"
    }
  }), [0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      position: "absolute",
      insetBlockStart: "22px",
      insetInlineStart: `${64 + i * 142}px`,
      width: "12px",
      height: "12px",
      borderRadius: "50%",
      background: "var(--brass-300)",
      boxShadow: "0 0 16px 4px rgba(227,176,75,.55)"
    }
  })), [["rice", 54], ["pasta", 168], ["chickpea", 928], ["lentil", 1042]].map(([k, x], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: "absolute",
      insetBlockStart: "34px",
      insetInlineStart: `${x}px`,
      width: "62px",
      height: "86px",
      borderRadius: "8px 8px 16px 16px",
      background: `linear-gradient(180deg, var(--ing-${k}), var(--ing-${k}-shade))`,
      border: "2px solid rgba(36,22,17,.4)",
      boxShadow: "var(--shadow-2)",
      opacity: 0.92
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetBlockStart: "-7px",
      insetInline: "14px",
      height: "12px",
      borderRadius: "6px",
      background: "#8d6a44",
      border: "2px solid rgba(36,22,17,.45)"
    }
  }))));
}

/** Language switch — present on every screen, top inline-end. */
function LangToggle({
  lang,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      padding: "3px",
      borderRadius: "var(--radius-pill)",
      background: "rgba(36,22,17,.62)",
      border: "2px solid rgba(227,176,75,.42)",
      gap: "2px"
    }
  }, [["en", "EN"], ["ar", "ع"]].map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    "data-ks-press": true,
    onClick: () => onChange(k),
    style: {
      minWidth: "46px",
      minHeight: "34px",
      border: "none",
      borderRadius: "var(--radius-pill)",
      cursor: "pointer",
      background: lang === k ? "linear-gradient(180deg,var(--brass-300),var(--brass-500))" : "transparent",
      color: lang === k ? "var(--char-900)" : "var(--cream-200)",
      font: `var(--fw-bold) var(--fs-body-sm)/1 var(--font-ui)`
    }
  }, l)));
}
Object.assign(window, {
  StreetBackdrop,
  ShopDressing,
  LangToggle
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/Scene.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/ShiftScreen.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge,
  Panel,
  StatReadout,
  ComboMeter,
  EventBanner,
  PatienceMeter,
  CustomerCard,
  OrderTicket,
  IngredientVat,
  KosharyBowl,
  ServeFeedback
} = window.KosharyUstaDesignSystem_f12ad9;

// mirrors patienceTone() in components/hud/PatienceMeter.jsx (lowercase exports
// aren't on the bundle namespace, so the thresholds are repeated here)
const toneFor = p => p > 60 ? "var(--state-good)" : p > 30 ? "var(--state-warn)" : "var(--state-fail)";
const VATS = ["rice", "lentils", "pasta", "chickpeas", "sauce", "onion", "daqqa", "shatta"];
const QUEUE = [{
  id: 1,
  en: "Office worker",
  ar: "موظف",
  icon: "office",
  patience: 62,
  order: [{
    key: "rice",
    qty: 2
  }, {
    key: "lentils",
    qty: 1
  }, {
    key: "pasta",
    qty: 1
  }, {
    key: "sauce",
    qty: 1
  }],
  note: {
    en: "Extra onion",
    ar: "بصل زيادة"
  }
}, {
  id: 2,
  en: "Tourist",
  ar: "سائح",
  icon: "tourist",
  patience: 88,
  order: [{
    key: "rice",
    qty: 1
  }, {
    key: "chickpeas",
    qty: 2
  }, {
    key: "sauce",
    qty: 1
  }],
  badge: {
    en: "First time",
    ar: "أول مرة"
  }
}, {
  id: 3,
  en: "Regular",
  ar: "زبون دايم",
  icon: "regular",
  patience: 47,
  order: [{
    key: "rice",
    qty: 3
  }, {
    key: "lentils",
    qty: 2
  }, {
    key: "onion",
    qty: 1
  }, {
    key: "shatta",
    qty: 1
  }]
}, {
  id: 4,
  en: "Family",
  ar: "عيلة",
  icon: "family",
  patience: 74,
  order: [{
    key: "rice",
    qty: 2
  }, {
    key: "pasta",
    qty: 2
  }, {
    key: "sauce",
    qty: 2
  }, {
    key: "onion",
    qty: 1
  }]
}, {
  id: 5,
  en: "Critic",
  ar: "ناقد",
  icon: "critic",
  patience: 30,
  order: [{
    key: "rice",
    qty: 2
  }, {
    key: "lentils",
    qty: 1
  }, {
    key: "daqqa",
    qty: 1
  }],
  note: {
    en: "No shatta",
    ar: "من غير شطة"
  },
  badge: {
    en: "Critic",
    ar: "ناقد"
  }
}];
const S = {
  en: {
    money: "Pounds",
    rep: "Rep",
    left: "Orders",
    pause: "Pause",
    serve: "Serve",
    kemala: "Kemala",
    clear: "Clear bowl",
    event: "Friday rush",
    detail: "The queue fills twice as fast. Keep the rice vat topped up.",
    mod: "−20% patience",
    ticket: "Now serving",
    empty: "Scoop from the vats to build the bowl."
  },
  ar: {
    money: "جنيه",
    rep: "السمعة",
    left: "طلبات",
    pause: "وقفة",
    serve: "قدّم",
    kemala: "كمالة",
    clear: "فضّي الطبق",
    event: "زحمة الجمعة",
    detail: "الطابور بيمتلي بسرعة الضعف. خلي حلة الرز مليانة.",
    mod: "−٢٠٪ صبر",
    ticket: "بنحضّر دلوقتي",
    empty: "اغرف من الحلل عشان تبني الطبق."
  }
};
function moodFor(p) {
  return p > 80 ? "delighted" : p > 60 ? "happy" : p > 40 ? "neutral" : p > 20 ? "impatient" : "annoyed";
}
function ShiftScreen({
  lang,
  setLang,
  onPause,
  onFinish
}) {
  const t = S[lang];
  const rtl = lang === "ar";
  const [queue, setQueue] = React.useState(QUEUE);
  const [bowl, setBowl] = React.useState([]);
  const [money, setMoney] = React.useState(1240);
  const [streak, setStreak] = React.useState(3);
  const [beat, setBeat] = React.useState(0);
  const [pop, setPop] = React.useState(null);
  const [armed, setArmed] = React.useState("rice");
  const active = queue[0];

  // the rhythm clock: one beat every 900ms, scooping near the top of it is "perfect"
  React.useEffect(() => {
    const id = setInterval(() => setBeat(b => (b + 0.08) % 1), 72);
    return () => clearInterval(id);
  }, []);
  React.useEffect(() => {
    const id = setInterval(() => setQueue(q => q.map((c, i) => ({
      ...c,
      patience: Math.max(0, c.patience - (i === 0 ? 0.9 : 0.35))
    }))), 1000);
    return () => clearInterval(id);
  }, []);
  const need = React.useMemo(() => {
    if (!active) return [];
    return active.order.map(l => ({
      ...l,
      filled: bowl.filter(b => b.key === l.key).length
    }));
  }, [active, bowl]);
  const over = need.some(l => l.filled > l.qty) || bowl.some(b => !active?.order.find(l => l.key === b.key));
  const done = need.every(l => l.filled >= l.qty) && !over;
  function flash(kind, value) {
    setPop({
      kind,
      value,
      at: Date.now()
    });
    setTimeout(() => setPop(p => p && p.at === Date.now() ? null : p), 900);
  }
  function scoop(key) {
    const onBeat = beat < 0.22 || beat > 0.86;
    setArmed(key);
    setBowl(b => [...b, {
      key
    }]);
    const spill = bowl.filter(x => x.key === key).length >= (active?.order.find(l => l.key === key)?.qty ?? 0);
    if (spill) {
      setStreak(0);
      flash("spill", null);
    } else if (onBeat) {
      setStreak(s => s + 1);
      flash("perfect", `+${8 + streak * 2}`);
    } else {
      setStreak(0);
      flash("good", "+5");
    }
  }
  function kemala() {
    setBowl(b => [...b, {
      key: "onion"
    }]);
    setStreak(s => s + 1);
    flash("kemala", "+15");
  }
  function serve() {
    if (!active) return;
    const mult = streak >= 6 ? 2 : streak >= 3 ? 1.5 : 1;
    if (over) {
      flash("miss", null);
      setStreak(0);
    } else {
      setMoney(m => m + Math.round(34 * mult));
      flash("perfect", `+${Math.round(34 * mult)}`);
    }
    setBowl([]);
    setQueue(q => q.slice(1));
  }

  // the shift ends when the last customer walks off
  React.useEffect(() => {
    if (!queue.length) {
      const id = setTimeout(onFinish, 800);
      return () => clearTimeout(id);
    }
  }, [queue.length, onFinish]);
  const multiplier = streak >= 6 ? 2 : streak >= 3 ? 1.5 : 1;
  return /*#__PURE__*/React.createElement("div", {
    dir: rtl ? "rtl" : "ltr",
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(StreetBackdrop, null), /*#__PURE__*/React.createElement(ShopDressing, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)",
      padding: "var(--space-5) var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.money
    }),
    label: t.money,
    value: money.toLocaleString("en-US"),
    bump: true
  }), /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.reputation
    }),
    label: t.rep,
    value: "4.6",
    tone: "herb"
  }), /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.ticket
    }),
    label: t.left,
    value: queue.length,
    tone: "clay"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginInlineStart: "auto",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(ComboMeter, {
    streak: streak,
    multiplier: multiplier,
    beat: beat
  }), /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    onChange: setLang
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    size: "sm",
    onClick: onPause,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.pause,
      size: "sm"
    })
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(EventBanner, {
    tone: "hazard",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.event
    }),
    title: t.event,
    detail: t.detail,
    modifier: t.mod
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)",
      padding: "var(--space-6) var(--space-7) 0"
    }
  }, queue.map((c, i) => /*#__PURE__*/React.createElement(CustomerCard, {
    key: c.id,
    compact: true,
    selected: i === 0,
    archetype: lang === "ar" ? c.ar : c.en,
    archetypeAr: lang === "ar" ? null : c.ar,
    mood: moodFor(c.patience),
    patience: c.patience,
    badge: c.badge ? /*#__PURE__*/React.createElement(Badge, {
      tone: c.id === 5 ? "fail" : "brass",
      size: "sm"
    }, lang === "ar" ? c.badge.ar : c.badge.en) : null,
    portrait: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS[c.icon],
      size: "44px",
      color: "var(--char-500)"
    })
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBlockStart: "auto",
      position: "relative",
      borderBlockStart: "5px solid #8a5a2e",
      background: "linear-gradient(180deg, var(--cream-200), var(--cream-400))",
      boxShadow: "0 -18px 48px rgba(0,0,0,.5), inset 0 8px 18px rgba(255,255,255,.5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0.5,
      backgroundImage: "linear-gradient(rgba(120,79,45,.16) 1px, transparent 1px), linear-gradient(90deg, rgba(120,79,45,.16) 1px, transparent 1px)",
      backgroundSize: "58px 58px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "flex-end",
      gap: "var(--space-6)",
      padding: "var(--space-7) var(--space-7) var(--space-8)",
      minHeight: "278px"
    }
  }, active ? /*#__PURE__*/React.createElement(OrderTicket, {
    index: 1,
    archetype: lang === "ar" ? active.ar : active.en,
    items: need,
    note: active.note ? lang === "ar" ? active.note.ar : active.note.en : null,
    noteTone: "warn",
    lang: lang,
    tone: toneFor(active.patience),
    state: over ? "failed" : done ? "perfect" : "open",
    style: {
      width: "220px"
    }
  }) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4, auto)",
      gap: "var(--space-4) var(--space-4)",
      alignItems: "end"
    }
  }, VATS.map(k => {
    const line = active?.order.find(l => l.key === k);
    const filled = bowl.filter(b => b.key === k).length;
    return /*#__PURE__*/React.createElement(IngredientVat, {
      key: k,
      ingredient: k,
      level: 62 + k.length * 7 % 32,
      steam: k === "rice" || k === "lentils" || k === "pasta" || k === "sauce",
      active: armed === k && !!line,
      overfill: !!line && filled > line.qty,
      count: filled || null,
      lang: lang,
      onScoop: () => scoop(k)
    });
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      marginInlineStart: "auto",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-4)",
      padding: "var(--space-5) var(--space-6) var(--space-5)",
      borderRadius: "var(--radius-panel)",
      background: "linear-gradient(180deg, rgba(36,22,17,.14), rgba(36,22,17,.24))",
      boxShadow: "var(--shadow-sunken)"
    }
  }, pop ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetBlockStart: "-58px",
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement(ServeFeedback, {
    kind: pop.kind,
    value: pop.value,
    bilingual: rtl
  })) : null, /*#__PURE__*/React.createElement(KosharyBowl, {
    size: 188,
    layers: bowl.length ? bowl : [],
    steam: bowl.length > 0,
    overfill: over
  }), !bowl.length ? /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-semibold) var(--fs-caption)/1.4 var(--font-ui)",
      color: "var(--cream-100)",
      maxWidth: "180px",
      textAlign: "center",
      textShadow: "0 1px 2px rgba(36,22,17,.55)"
    }
  }, t.empty) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    size: "sm",
    onClick: kemala,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.kemala,
      size: "sm"
    })
  }, t.kemala), /*#__PURE__*/React.createElement(Button, {
    variant: done ? "brass" : "primary",
    onClick: serve,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.serve,
      size: "sm"
    })
  }, t.serve)))))), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetBlockEnd: 0,
      insetInline: 0,
      height: "18px",
      background: "linear-gradient(180deg,#a8703f,var(--surface-counter))",
      borderBlockStart: "3px solid #5e3a1c",
      zIndex: 3
    }
  }));
}
Object.assign(window, {
  ShiftScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/ShiftScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/ShopScreen.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge,
  Panel,
  StatReadout,
  UpgradeCard
} = window.KosharyUstaDesignSystem_f12ad9;
const UPGRADES = [{
  icon: "rice",
  en: "Big rice vat",
  ar: "حلة رز كبيرة",
  tier: "Equipment",
  tierAr: "معدات",
  desc: {
    en: "Hold twice as much rice, so the lunch rush never dries you out.",
    ar: "تشيل ضعف الرز، فـ زحمة الضهر عمرها ما تنشّفك."
  },
  price: "320",
  level: 2,
  maxLevel: 4
}, {
  icon: "kemala",
  en: "Generous hand",
  ar: "إيد كريمة",
  tier: "Skill",
  tierAr: "مهارة",
  desc: {
    en: "Widens the perfect-scoop window by a beat.",
    ar: "بتوسّع وقت الغرفة المظبوطة بضربة زيادة."
  },
  price: "450",
  level: 1,
  maxLevel: 3
}, {
  icon: "customer",
  en: "Prep boy",
  ar: "صبي التحضير",
  tier: "Staff",
  tierAr: "عمالة",
  desc: {
    en: "Refills one vat for you between customers.",
    ar: "بيملالك حلة واحدة بين الزباين."
  },
  price: "780",
  affordable: false
}, {
  icon: "shop",
  en: "Painted awning",
  ar: "تندة مدهونة",
  tier: "Shopfront",
  tierAr: "الواجهة",
  desc: {
    en: "Shade out front. Walk-ins wait a little longer before they leave.",
    ar: "ضل قدام المحل. الزباين بتستنى شوية زيادة قبل ما تمشي."
  },
  owned: true
}, {
  icon: "shatta",
  en: "House shatta",
  ar: "شطة البيت",
  tier: "Recipe",
  tierAr: "وصفة",
  desc: {
    en: "Regulars tip more when you finish with your own chilli.",
    ar: "الزباين الدايمة بتبقشش أكتر لما تخلص بشطتك."
  },
  price: "540",
  affordable: false
}, {
  icon: "reputation",
  en: "Signboard",
  ar: "لافتة",
  tier: "Shopfront",
  tierAr: "الواجهة",
  desc: {
    en: "One more customer joins the queue each shift.",
    ar: "زبون زيادة بيدخل الطابور كل وردية."
  },
  price: "260",
  level: 1,
  maxLevel: 2
}];
const SH = {
  en: {
    title: "The Shop",
    sub: "Sayeda Zeinab · Day 7",
    back: "Back",
    money: "Pounds",
    buy: "Buy",
    owned: "Owned",
    next: "Start Shift"
  },
  ar: {
    title: "المحل",
    sub: "السيدة زينب · اليوم ٧",
    back: "رجوع",
    money: "جنيه",
    buy: "اشتري",
    owned: "عندك",
    next: "ابدأ الورديّة"
  }
};
function ShopScreen({
  lang,
  setLang,
  onBack,
  onStart
}) {
  const t = SH[lang];
  const rtl = lang === "ar";
  const [money, setMoney] = React.useState(1240);
  const [bought, setBought] = React.useState([]);
  return /*#__PURE__*/React.createElement("div", {
    dir: rtl ? "rtl" : "ltr",
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--surface-page)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(90% 70% at 50% 0%, rgba(227,176,75,.22), transparent 65%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      padding: "var(--space-7) var(--space-9) var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    size: "sm",
    onClick: onBack,
    icon: /*#__PURE__*/React.createElement("i", {
      className: "ph-fill ph-arrow-left",
      "data-ks-flip": true
    })
  }, t.back), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `400 ${rtl ? 36 : 34}px/1.1 var(--font-display)`,
      color: "var(--text-strong)"
    }
  }, t.title), /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--fw-semibold) var(--fs-caption)/1 var(--font-ui)",
      color: "var(--text-muted)",
      letterSpacing: "var(--ls-wide)"
    }
  }, t.sub)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginInlineStart: "auto",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(StatReadout, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.money
    }),
    label: t.money,
    value: money.toLocaleString("en-US"),
    size: "lg",
    bump: true
  }), /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    onChange: setLang
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: "0 var(--space-9) var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-5)"
    }
  }, UPGRADES.map((u, i) => {
    const owned = u.owned || bought.includes(i);
    return /*#__PURE__*/React.createElement(UpgradeCard, {
      key: i,
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: KS_ICONS[u.icon],
        size: "lg"
      }),
      title: lang === "ar" ? u.ar : u.en,
      titleAr: lang === "ar" ? null : u.ar,
      tier: lang === "ar" ? u.tierAr : u.tier,
      description: lang === "ar" ? u.desc.ar : u.desc.en,
      price: u.price,
      owned: owned,
      affordable: u.affordable !== false,
      level: u.level,
      maxLevel: u.maxLevel,
      buyLabel: owned ? t.owned : t.buy,
      onBuy: () => {
        if (!owned && u.affordable !== false) {
          setBought(b => [...b, i]);
          setMoney(m => m - Number(u.price));
        }
      }
    });
  }))), /*#__PURE__*/React.createElement("footer", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      padding: "0 var(--space-9) var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "brass",
    size: "lg",
    onClick: onStart,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.bowl,
      size: "md"
    })
  }, t.next))));
}
Object.assign(window, {
  ShopScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/ShopScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game/TitleScreen.jsx
try { (() => {
const {
  Button,
  Icon,
  KS_ICONS,
  Badge,
  StarRating
} = window.KosharyUstaDesignSystem_f12ad9;
const T = {
  en: {
    play: "Start Shift",
    cont: "Continue",
    shop: "Shop",
    tagline: "Run the busiest koshary counter in Cairo.",
    day: "Day 7 · Sayeda Zeinab",
    best: "Best day"
  },
  ar: {
    play: "ابدأ الورديّة",
    cont: "كمّل",
    shop: "المحل",
    tagline: "شغّل أشهر عربية كشري في القاهرة.",
    day: "اليوم ٧ · السيدة زينب",
    best: "أحسن يوم"
  }
};
function TitleScreen({
  lang,
  setLang,
  onPlay,
  onShop
}) {
  const t = T[lang];
  const rtl = lang === "ar";
  return /*#__PURE__*/React.createElement("div", {
    dir: rtl ? "rtl" : "ltr",
    style: {
      position: "absolute",
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(StreetBackdrop, null), /*#__PURE__*/React.createElement(ShopDressing, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      insetBlockStart: "var(--space-7)",
      insetInlineEnd: "var(--space-8)",
      zIndex: 3
    }
  }, /*#__PURE__*/React.createElement(LangToggle, {
    lang: lang,
    onChange: setLang
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "grid",
      placeItems: "center",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      lineHeight: 0.9,
      textShadow: "0 6px 0 rgba(94,36,18,.55), 0 18px 40px rgba(0,0,0,.5)"
    }
  }, rtl ? /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 108px/1.12 var(--font-display)`,
      color: "var(--cream-50)"
    }
  }, "\u0643\u0634\u0631\u064A ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--brass-300)"
    }
  }, "\u0623\u0633\u0637\u0649")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 96px/1 var(--font-display)`,
      color: "var(--cream-50)"
    }
  }, "Koshary"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: `400 96px/1 var(--font-display)`,
      color: "var(--brass-300)"
    }
  }, "Usta"))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      font: `var(--fw-semibold) var(--fs-body-lg)/${rtl ? 1.7 : 1.45} var(--font-ui)`,
      color: "var(--cream-200)",
      textAlign: "center",
      maxWidth: "520px"
    }
  }, t.tagline), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)",
      width: "300px",
      marginBlockStart: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "brass",
    size: "lg",
    block: true,
    onClick: onPlay,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.bowl,
      size: "md"
    })
  }, t.play), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    block: true,
    onClick: onPlay
  }, t.cont), /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    block: true,
    onClick: onShop,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: KS_ICONS.shop,
      size: "sm"
    })
  }, t.shop))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      marginBlockStart: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "night"
  }, t.day), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-3)",
      whiteSpace: "nowrap",
      font: `var(--fw-semibold) var(--fs-caption)/1 var(--font-ui)`,
      color: "var(--cream-300)"
    }
  }, t.best, " ", /*#__PURE__*/React.createElement(StarRating, {
    value: 3,
    size: 16
  }))))), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      insetBlockEnd: 0,
      insetInline: 0,
      height: "76px",
      background: "linear-gradient(180deg,#a8703f,var(--surface-counter))",
      borderBlockStart: "4px solid #5e3a1c",
      boxShadow: "0 -14px 40px rgba(0,0,0,.45)"
    }
  }));
}
Object.assign(window, {
  TitleScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game/TitleScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.KS_GLYPHS = __ds_scope.KS_GLYPHS;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.PanelHeading = __ds_scope.PanelHeading;

__ds_ns.PanelRule = __ds_scope.PanelRule;

__ds_ns.ARCH = __ds_scope.ARCH;

__ds_ns.ARCH_FROM = __ds_scope.ARCH_FROM;

__ds_ns.CustomerFigure = __ds_scope.CustomerFigure;

__ds_ns.IngredientVat = __ds_scope.IngredientVat;

__ds_ns.KosharyBowl = __ds_scope.KosharyBowl;

__ds_ns.ING = __ds_scope.ING;

__ds_ns.OrderTicket = __ds_scope.OrderTicket;

__ds_ns.PrepCard = __ds_scope.PrepCard;

__ds_ns.ServeFeedback = __ds_scope.ServeFeedback;

__ds_ns.StatRows = __ds_scope.StatRows;

__ds_ns.StatRow = __ds_scope.StatRow;

__ds_ns.ComboMeter = __ds_scope.ComboMeter;

__ds_ns.EventBanner = __ds_scope.EventBanner;

__ds_ns.Meter = __ds_scope.Meter;

__ds_ns.PatienceMeter = __ds_scope.PatienceMeter;

__ds_ns.Shout = __ds_scope.Shout;

__ds_ns.StatReadout = __ds_scope.StatReadout;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.VENUES = __ds_scope.VENUES;

__ds_ns.ChapterCard = __ds_scope.ChapterCard;

__ds_ns.StarRating = __ds_scope.StarRating;

__ds_ns.UpgradeCard = __ds_scope.UpgradeCard;

})();
